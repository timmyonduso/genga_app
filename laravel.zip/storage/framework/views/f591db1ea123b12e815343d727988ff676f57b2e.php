<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('loan_application_create')): ?>
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route('admin.loan-applications.create')); ?>">
                <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.loanApplication.title_singular')); ?>

            </a>
        </div>
    </div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.loanApplication.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-LoanApplication">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.loanApplication.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.loanApplication.fields.loan_amount')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.loanApplication.fields.repayment_date')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.loanApplication.fields.interest')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.loanApplication.fields.penalty')); ?>

                        </th>



                        <th>
                            <?php echo e(trans('cruds.loanApplication.fields.overdue')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.loanApplication.fields.status')); ?>

                        </th>








                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $loanApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $loanApplication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($loanApplication->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($loanApplication->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($loanApplication->loan_amount ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($loanApplication->repayment_date ? $loanApplication->repayment_date->format('Y-m-d') : ''); ?>

                            </td>
                            <td>
                                <?php echo e($loanApplication->interest_rate ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(number_format($loanApplication->penalty_amount, 2)); ?>

                            </td>
                            


                            <td>
                                <?php if($loanApplication->overdue): ?>
                                    Yes
                                <?php else: ?>
                                    No
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($user->is_user && $loanApplication->status_id < 8 ? $defaultStatus->name : $loanApplication->status->name); ?>

                            </td>








                            <td>
                                <?php if($user->is_admin && in_array($loanApplication->status_id, [1, 3, 4])): ?>
                                    <a class="btn btn-xs btn-success" href="<?php echo e(route('admin.loan-applications.showSend', $loanApplication->id)); ?>">
                                        Send to
                                        <?php if($loanApplication->status_id == 1): ?>
                                            Secretary
                                        <?php else: ?>
                                            Secretary 2
                                        <?php endif; ?>
                                    </a>
                                <?php elseif(($user->is_analyst && $loanApplication->status_id == 2) || ($user->is_cfo && $loanApplication->status_id == 5)): ?>
                                    <a class="btn btn-xs btn-success" href="<?php echo e(route('admin.loan-applications.showAnalyze', $loanApplication->id)); ?>">
                                        Submit analysis
                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('loan_application_show')): ?>
                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.loan-applications.show', $loanApplication->id)); ?>">
                                        <?php echo e(trans('global.view')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if(Gate::allows('loan_application_edit') && in_array($loanApplication->status_id, [3,6,7])): ?>
                                    <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.loan-applications.edit', $loanApplication->id)); ?>">
                                        <?php echo e(trans('global.edit')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('loan_application_delete')): ?>
                                    <form action="<?php echo e(route('admin.loan-applications.destroy', $loanApplication->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                                    </form>
                                <?php endif; ?>

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('loan_application_delete')): ?>
  let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "<?php echo e(route('admin.loan-applications.massDestroy')); ?>",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

        return
      }

      if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
<?php endif; ?>

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-LoanApplication:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });

})

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\timmy\Desktop\xampp\htdocs\Laravel-Loan-Management-Demo-master\resources\views/admin/loanApplications/index.blade.php ENDPATH**/ ?>