<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\timmy\Desktop\xamp\htdocs\Laravel-Loan-Management-Demo-master\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>