<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.loanApplication.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.loan-applications.update", [$loanApplication->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="loan_amount"><?php echo e(trans('cruds.loanApplication.fields.loan_amount')); ?></label>
                <input class="form-control <?php echo e($errors->has('loan_amount') ? 'is-invalid' : ''); ?>" type="dat" name="loan_amount" id="loan_amount" value="<?php echo e(old('loan_amount', $loanApplication->loan_amount)); ?>" step="0.01" required>
                <?php if($errors->has('loan_amount')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('loan_amount')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.loanApplication.fields.loan_amount_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="description"><?php echo e(trans('cruds.loanApplication.fields.description')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('description') ? 'is-invalid' : ''); ?>" name="description" id="description"><?php echo e(old('description', $loanApplication->description)); ?></textarea>
                <?php if($errors->has('description')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('description')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.loanApplication.fields.description_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="repayment_date"><?php echo e(trans('cruds.loanApplication.fields.repayment_date')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('repayment_date') ? 'is-invalid' : ''); ?>" name="repayment_date" id="repayment_date"><?php echo e(old('repayment_date', $loanApplication->repayment_date)); ?></textarea>

                <?php if($errors->has('repayment_date')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('repayment_date')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.loanApplication.fields.repayment_date_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="status_id"><?php echo e(trans('cruds.loanApplication.fields.status')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('status') ? 'is-invalid' : ''); ?>" name="status_id" id="status_id">
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('status_id') == $id ? 'selected' : ''); ?>><?php echo e($status); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('status')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('status')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.loanApplication.fields.status_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\timmy\Desktop\xampp\htdocs\Laravel-Loan-Management-Demo-master\resources\views/admin/loanApplications/edit.blade.php ENDPATH**/ ?>