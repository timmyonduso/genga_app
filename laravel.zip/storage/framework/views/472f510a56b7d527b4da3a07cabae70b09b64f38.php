<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Timmy Email</title>
</head>
<body>
    <h3>Genga Welfare Group</h3>
    <br>
<p><?php echo e($data['body']); ?></p>
</body>
</html>
<?php /**PATH C:\Users\timmy\Desktop\xamp\htdocs\Laravel-Loan-Management-Demo-master\resources\views/emails/index.blade.php ENDPATH**/ ?>