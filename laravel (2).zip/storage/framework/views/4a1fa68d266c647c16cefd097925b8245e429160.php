<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            Analysis
        </div>

        <div class="card-body">
            <form method="POST" action="<?php echo e(route("admin.loan-applications.analyze", $loanApplication)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="description"><?php echo e(trans('cruds.comment.title_singular')); ?></label>
                    <textarea class="form-control <?php echo e($errors->has('comment_text') ? 'is-invalid' : ''); ?>" name="comment_text" id="comment_text"><?php echo e(old('comment_text')); ?></textarea>
                    <?php if($errors->has('comment_text')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('comment_text')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <button class="btn btn-success" name="approve" type="submit">
                        Approve
                    </button>
                    <button class="btn btn-danger" name="reject" type="submit">
                        Reject
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\timmy\Desktop\xampp\htdocs\Laravel-Loan-Management-Demo-master\resources\views/admin/loanApplications/analyze.blade.php ENDPATH**/ ?>