<?php

return [
    'site_title' => 'Club 21',
];
